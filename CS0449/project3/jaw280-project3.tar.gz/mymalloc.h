void *my_worstfit_malloc(int size);
void my_free(void *ptr);
